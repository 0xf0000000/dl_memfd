#include <jni.h>
#include <android/log.h>

#define LOG_TAG "log"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

void payload_function() {
    LOGI("Payload function executed successfully. Library loaded via dl_memfd.");
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
    payload_function();
    return JNI_VERSION_1_6;
}
