#include <jni.h>
#include <android/log.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <dlfcn.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define LOG_TAG "logx"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#if defined(__arm__) || defined(__aarch64__)
#define __NR_memfd_create 385
#elif defined(__i386__)
#define __NR_memfd_create 356
#elif defined(__x86_64__)
#define __NR_memfd_create 319
#endif

int memfd_create(const char *name, unsigned int flags) {
    return syscall(__NR_memfd_create, name, flags);
}

char* read_file_to_buffer(const char* path, size_t* size) {
    FILE* file = fopen(path, "rb");
    long file_size;
    char* buffer;

    if (!file) {
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    file_size = ftell(file);
    fseek(file, 0, SEEK_SET);

    buffer = (char*)malloc(file_size);
    if (!buffer) {
        fclose(file);
        return NULL;
    }

    if (fread(buffer, 1, file_size, file) != file_size) {
        free(buffer);
        fclose(file);
        return NULL;
    }

    fclose(file);
    *size = (size_t)file_size;
    return buffer;
}

JNIEXPORT void JNICALL
Java_com_example_dlmemfdexample_MainActivity_startInjection(
        JNIEnv* env,
        jobject thiz,
        jstring lib_path) {

    const char *lib_path_c = (*env)->GetStringUTFChars(env, lib_path, 0);
    char *lib_content;
    size_t lib_size = 0;
    int memfd;
    ssize_t written;
    char memfd_path[64];
    void* handle;

    lib_content = read_file_to_buffer(lib_path_c, &lib_size);
    (*env)->ReleaseStringUTFChars(env, lib_path, lib_path_c);

    if (!lib_content) {
        LOGE("Failed to read library content.");
        return;
    }

    memfd = memfd_create("anon_lib", MFD_CLOEXEC | MFD_ALLOW_SEALING);
    if (memfd < 0) {
        LOGE("memfd_create failed: %s", strerror(errno));
        free(lib_content);
        return;
    }

    written = write(memfd, lib_content, lib_size);
    free(lib_content);

    if (written != (ssize_t)lib_size) {
        LOGE("Write to memfd failed. Wrote: %zd, Expected: %zu", written, lib_size);
        close(memfd);
        return;
    }

    if (fcntl(memfd, F_ADD_SEALS, F_SEAL_GROW | F_SEAL_SHRINK | F_SEAL_WRITE) < 0) {
        LOGE("Sealing memfd failed: %s", strerror(errno));
        close(memfd);
        return;
    }

    snprintf(memfd_path, sizeof(memfd_path), "/proc/self/fd/%d", memfd);
    
    handle = dlopen(memfd_path, RTLD_LAZY);
    
    close(memfd);

    if (!handle) {
        LOGE("dlopen failed: %s", dlerror());
        return;
    }
}
