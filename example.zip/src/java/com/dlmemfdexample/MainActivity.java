package com.dlmemfdexample;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;

public class MainActivity extends Activity {

    // Load the native library. (trickzqw)
    static {
        System.loadLibrary("trickzqw");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView tv = findViewById(R.id.sample_text);
        tv.setText("inject");

        Button injectButton = findViewById(R.id.inject_button);
        injectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String libPath = getFilesDir().getAbsolutePath() + "/liblib_to_inject.so";
                startInjection(libPath);
                tv.setText("Injection started.");
            }
        });
    }

    // Native method that calls the C++ injector.
    public native void startInjection(String libPath);
}
